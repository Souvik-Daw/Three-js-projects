# r3f-responsive-final


![responsive-thumbnail](https://github.com/wass08/r3f-responsive-final/assets/6551176/9a9a9095-252f-4b08-9578-c01d9225cfa2)

[Video tutorial](https://youtu.be/lE16LkzA6fc)

[Starter pack](https://github.com/wass08/r3f-responsive-starter/)
