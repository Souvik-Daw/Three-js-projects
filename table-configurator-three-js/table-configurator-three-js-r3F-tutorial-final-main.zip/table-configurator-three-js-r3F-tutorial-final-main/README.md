# Table configurator R3F tutorial final

This is the final project to build the Table Configurator using React Three Fiber

[Live preview](https://codesandbox.io/p/github/wass08/table-configurator-three-js-r3F-tutorial-final/main?workspaceId=5cd54208-3423-4f91-a7e8-14ca07bdc9af&file=%2Fsrc%2FApp.jsx&workspace=%257B%2522activeFileId%2522%253A%2522cle3xpej5000dfqcr62lhgi7d%2522%252C%2522openFiles%2522%253A%255B%255D%252C%2522sidebarPanel%2522%253A%2522EXPLORER%2522%252C%2522gitSidebarPanel%2522%253A%2522COMMIT%2522%252C%2522spaces%2522%253A%257B%2522cle3xpha0000e3b6qo1nn3d6i%2522%253A%257B%2522key%2522%253A%2522cle3xpha0000e3b6qo1nn3d6i%2522%252C%2522name%2522%253A%2522Default%2522%252C%2522devtools%2522%253A%255B%257B%2522type%2522%253A%2522PREVIEW%2522%252C%2522taskId%2522%253A%2522dev%2522%252C%2522port%2522%253A5173%252C%2522key%2522%253A%2522cle3xpsqm008c3b6qzw5v4j5s%2522%252C%2522isMinimized%2522%253Afalse%257D%255D%257D%257D%252C%2522currentSpace%2522%253A%2522cle3xpha0000e3b6qo1nn3d6i%2522%252C%2522spacesOrder%2522%253A%255B%2522cle3xpha0000e3b6qo1nn3d6i%2522%255D%252C%2522hideCodeEditor%2522%253Afalse%257D)

![Screenshot 2023-02-14 at 16 37 29](https://user-images.githubusercontent.com/6551176/218670344-0b1b20fe-bf0e-43e6-a64d-bc22395b7582.jpg)

The starter pack is available [here](https://github.com/wass08/table-configurator-three-js-r3F-tutorial-starter)

## Setup & run 

```
yarn
yarn dev
```
